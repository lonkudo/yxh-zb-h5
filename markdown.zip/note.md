# Vue 数组的响应式问题

```javascript
			open(index, outerIndex, list) {
				console.log('open', index, list[index])
				// 先将正在被操作的swipeAction标记为打开状态，否则由于props的特性限制，
				// 原本为'false'，再次设置为'false'会无效
				this.handleData(list)
				list[outerIndex].list[index].show = true
				console.log('this.', this.newsList)
				this.newsList = JSON.parse(JSON.stringify(list))
			},
```

- Vue 会根据 diff 算法来比较虚拟 DOM 进行识图的更新，所以 key 不变的 虚拟 DOM 是不会进行视图上的更新的。
- 所以仅仅是改变数组里面的某一个对象的某一个属性，这个数组不会改变。这个时候可以先对数组进行修改。
- 修改完成以后，如果直接把数组赋值给原数组是没有用的。因为本来就是传递的索引，在元素组上进行了修改，这种赋值操作没有任何意义。
- 正确的做法是使用 this.$set 来进行修改。
- 如果是复杂数组，多层嵌套的，可以使用深拷贝，然后把拷贝的结果赋值给源数组。javascript 里面的 deepCopy 用 JSON.parse(JSON.stringify(arr))就可以完成。

# u-swiper-action 的应用

如图所示：左滑删除有封装好的组件，这里用的是 uView 的组件
![u-swiper-action](/markdown/img/u-swiper-action-exmple.jpg)

```html
<u-swipe-action
	:show="item.show"
	:index="index"
	@click="click(index, time.list)" // 右拉菜单触发click方法
	@open="open(index, idx, newsList)" // open方法处理菜单的打开唯一性
	:options="options"
	v-for="(item, index) in time.list"
	:key="index"
>
	<view class="flex">
		<image
			:src="item.mediaw.thumb"
			mode="aspectFill"
			class="br-8"
			style="width: 180rpx; height: 100rpx"
		/>
		<view class="margin-left-xs flex flex-direction justify-between"
			><text class="f-hide w-500 fs-20">{{ item.mediaw.title }}</text
			><text class="fc-b-9 fs-20"
				>{{ item.mediaw.addtime | formatGiven('yyyy-MM-dd hh:ss') }}</text
			></view
		>
	</view>
</u-swipe-action>
```

# 自定义参数覆盖原生参数的问题

```html
<u-swipe-action
	:show="item.show"
	:index="index"
	@click="click"
	@open="open(index, idx, newsList)"
	:options="options"
	v-for="(item, index) in time.list"
	:key="index"
></u-swipe-action>
```

u-swiper-action 这个组件封装好了 click 方法。这种时候如果我们把参数写成 click(list) 想要传递自己的参数进去，就会覆盖掉他的参数

可以通过项目查询，找到这个组件封好的原生组件，然后查看他传参的方式。
把这个组件取出来，变成自己定义的方法。之前那个 tab,tabNav,tabPane。也是通过这种找到原生组件再自定义的方法来搞定的。

注意不要影响到全局的组件，不要同名。

- 突然发现也可以用函数调用的形式传递参数进去

```javascript
@on-list-change="
  (args) => {
    onChoose(item, args)
  }
"
```

# vant 开发和 uniapp 开发

vant 只是适配 H5，默认是适配 px 作为像素。uniapp 是面向所有端的，他的开发需要花经理去调试各个端的兼容性。已经有原生安卓和 IOS 的情况下，vant 开发 H5 会更加高效。

# 直接使用 callback 来操作 原来的数组

```javascript
click(index, index1, list, type) {
  let mediaid = list[index].mediaid
  this.delMyCollection(list[index].mediaid, type, () => {
    list.splice(index, 1)
    this.$u.toast(`deleted`)
  })
},
      /* 删除我的收藏 */
delMyCollection(mediaid, type, callback) {
  delMyCollection(this.uid, this.token, mediaid, type)
    .then((res) => {
      callback()
    })
    .catch((err) => {
      // this.$message.error('3')
    })
},
```

删除操作成功以后，要进行对应的操作，直接使用 callback，简洁清晰方便。

# 单元测试

单元测试是为了避免一些重复性太高的测试活动而存在的。比如说微信的开发，有些地方的修改会联动到其他页面，这种联动是隐性的，你不留意不会注意到。而且每次修改对应的模块都要重新测试一下所有关联到的地方很繁琐，所以要做单元测试。

除了单元测试还有 UI 测试，UI 测试类似于脚本，可以定时在在特定位置触发点击事件等。这种测试可以用来测试一些暴力事件，比如说，你同一个步骤操作 100 次以后，才会发生内存泄漏，你不可能自己手动重复同一个动作 100 次。所以会有这种 ui 测试存在。

# 增加或者删除 OBJECT 里面的属性 通过一定方法视图可以更新。但是修改 OBJECT 里面的属性，不管怎么样，视图都不更新。

```javascript
this.videoData.iscollection = info.iscollection
this.videoData.collections = info.collections
this.videoData = JSON.parse(
	JSON.stringify(
		Object.assign(this.videoData, {
			iscollection: info.iscollection,
			collections: info.collections,
		})
	)
)
this.$set(this.videoData, 'iscollection', info.iscollection)
this.$set(this.videoData, 'collections', info.collections)
// 更新不了，这些都是错误的。
```

# 局部变量和全局变量的生命周期

局部变量的生命周期是从创建开始到出作用域的范围
全局变量的生命周期是从程序运行开始到程序结束

全局变量只要声明在 main 之外，当跨文件使用的时候要加上 external 来访问。

# 常变量

const int a = 10;
这种声明形式，就声明了常变量。在一些场景下面常变量无法使用。比如说：
const arr[n] = [0] 创建一个 10 个元素的数组，数组的元素初始化值是 0。
数组 arr[] 括号里只能放常量，不能放变量。

# websocket 和 socketIO

// nodejs-websocket

```javascript
var ws = require('nodejs-websocket')

// Scream server example: "hi" -> "HI!!!"
// server side
var server = ws
	.createServer(function (conn) {
		console.log('New connection')
		conn.on('text', function (str) {
			console.log('Received ' + str)
			conn.sendText(str.toUpperCase() + '!!!')
		})
		conn.on('close', function (code, reason) {
			console.log('Connection closed')
		})
	})
	.listen(8001)

// broadcast
function broadcast(server, msg) {
	server.connections.forEach(function (conn) {
		conn.sendText(msg)
	})
}
// client side
const socket = new WebSocket('ws://localhost:8080')

// Connection opened
socket.addEventListener('open', function (event) {
	socket.send('Hello Server!')
})

// Listen for messages
socket.addEventListener('message', function (event) {
	console.log('Message from server ', event.data)
})

// nodejs-websocket 没有封装好基础的广播方法。数据需要自己通过JSON.stringify来处理。
// socketIO 分装好了一些方法，然后可以自定义事件。

// server side
const app = require('express')()
const server = require('http').createServer(app)
const io = require('socket.io')(server)
io.on('connection', (socket) => {
	socket.emit('request' /* … */) // emit an event to the socket
	io.emit('broadcast' /* … */) // emit an event to all connected sockets
	socket.on('reply', () => {}) // listen to the event
})


server.listen(3000)


// client side
<script>
  var socket = io(); // url
  $('form').submit(function(){
    socket.emit('chat message', $('#m').val());
    $('#m').val('');
    return false;
  });
  socket.on('chat message', function(msg){
    $('#messages').append($('<li>').text(msg));
  });
</script>
```

# v-html 让模板直接不转义插入富文本。 注意要防止 xss 攻击。

```html
<view v-html="particular"></view>
```

```javascript
								this.newsDetails.particular = this.newsDetails.particular
									.replace(/&amp;/g, '&')
									.replace(/&lt;/g, '<')
									.replace(/&gt;/g, '>')
									.replace(/&nbsp;/g, ' ')
									.replace(/&#39;/g, "'")
									.replace(/&quot;/g, '"')
									.replace(/<p>/g, '<view>')
									.replace(/<\/p>/g, '</view>')
									.replace(/script/g, 'text')
							}
							console.log(this.newsDetails.particular)
							this.particular = this.newsDetails.particular
```

# 获取屏幕高度，两个方法，有一个获取的数据不正确。

```javascript
export default async function (height) {
	console.log('111111')
	var Height = uni.getSystemInfoSync().screenHeight // 正确
	var Width = uni.getSystemInfoSync().screenWidkth // 正确
	console.log('当前高度: ' + JSON.stringify(Height))
	console.log('当前宽度: ' + JSON.stringify(Width))
	const ret = await new Promise((resolve) => {
		uni.getSystemInfo({
			success: function (res) {
				/* 获取每个rpx对应的像素数量 */
				const unit = res.windowWidth / 750
				console.log('1-1-1-1-1-1', res.windowWidth, res.windowHeight) // 部分设备错误。
				resolve(Math.ceil(res.windowHeight / unit) - height)
			},
		})
	})
```

# video 组件的绑定返回问题。 uniapp 内建组件 video 没有绑定的返回按钮。做了一个固定定位的返回，@play 隐藏；默认，@ended，@pause,显示

# 初始化参数问题 有的时候页面切换可以预先传入一部分数据，再去重新请求数据，这样的用户体验会比较好。

比如说从视频列表到视频详情页，视频列表页面携带了用户名，等参数给视频详情页。视频详情页有了这些数据，就可以先渲染一部分的页面出来，如果重新去要数据，就要等这个请求加载完才能渲染页面，用户体验会差一些，具体看请求的速度。

# uniapp 节点操作

有两种方案，一个直接使用 this.$refs.dom 给元素添加 ref，然后用 vue 方法来操作。
具体找时间去学习一下节点操作。
一种

```javascript
const query = uni.createQuerySelector().in(this) // 创建一个节点选择器
query.select('#mydom') // 这个节点选择器进行选择。
```

# 使用 socket.io 来进行链接。

去 socekt.io 官网，发现他有 4 个版本的服务端，客户端。不同的版本适配不同服务端和客户端。我们使用的是 2.x 版本。非常低的版本。不知道为啥全都是使用低版本的。

```javascript
// main.js
import io from '@/uni_modules/socket.io-client'
console.log('io', io)
Vue.prototype.io = io
// live.vue
this.ws = this.io(this.roomInfo.chatserver)
console.log('---start----start----start----start----start---', this.ws, this.io)
this.ws.on('connect', (e) => {
	console.log('链接', e)
	this.ws.on('broadcastingListen', (data) => {
		console.log('mes', data)
	})
}) // 不同版本的socket.io-client有不同的启动方式。
```

# websocket.io 链接

在这个而项目里面.链接建立以后，要先确认链接，服务端才会推送信息过来，确认方式：

```javascript
this.ws.emit('conn', roomObj)
```

通讯过程截图：
![websocket通讯](/markdown/img/websocket.jpg)

# vuex 保存用户 snippet

注意点：1、this.$store.commit('add_sni','str') 而不是 this.$store.state.snippet.commit()
2、要添加索引用于查询记录
3、uniapi 封装好了方法。 直接用 sync 方法不然是异步的，且他会自动序列化数据

```javascript
const snippet = {
	state: {
		snippetList: uni.getStorageSync('snippetList') || [],
	},

	mutations: {
		add_sni: function (state, str) {
			const timestamp = new Date()
			state.snippetList.push({ time: timestamp, msg: str })
			uni.setStorage({
				key: 'snippetList',
				data: state.snippetList,
			})
		},
		del_sni: function (state, obj) {
			const index = state.snippetList.findIndex((ele) => {
				return ele.timestamp === obj.timestamp
			})
			state.snippetList.splice(index, 1)
			uni.setStorageSync('snippetList', state.snippetList) // 不需要JSON.stringify JSON.parse 他已经封装过了。
		},
	},
}

export default snippet
```

# websocket websocket 打开 ws 检查请求情况。

如果状态是 pending 就是正在链接中，结束以后会有链接时长记时。
websocekt 链接的时候调用 open 方法，关闭不是 this.$emit('close') 而是直接 socket.close()

debug 过程截图：
![websocketDEBUG](/markdown/img/websocket2.jpg)

# C 语言 常量类型

1. 自定义常量

```c
   int 30;
```

2. 常变量

```c
   const int a = 30;
```

3. define 定义的标识符常量

```c
   #define MAX 10000 ;
```

4. 枚举类型

```c
   enum Sex {
   MALE,
   FEMALE,
   SECRET,
   }
```

# 传值方式

函数传值：
这个传值这次函数的运行过程里面值是不会变的。
函数传递值得时候传递的是对象，会变化吗？？？

```javascript
			sendGift(giftId,giftInfo,giftNum) {
				/* 赠送礼物 */
				this.guard()
				if (!giftId) return this.$u.toast('please choose a type of gift')
```

this 传值： 有可能运算过程里面值会变化

```javascript
			sendGift(giftId,giftInfo,giftNum) {
				/* 赠送礼物 */
				this.guard()
				if (!this.giftId) return this.$u.toast('please choose a type of gift')
```

# export 的方式总结

# 学习一下高级的动画效果。

![websocketDEBUG](/markdown/img/textwave.webp)

# transition 动画：

transition 组件 小写开头大写开头都能使用。
有六种状态可以指定样式

1. 动画进入前 .slide-enter-from
2. 动画进入后 .slide-enter-to
3. 动画进入时段 .slide-enter-active 这个时间段指定动画

4. 动画离开前 .slide-leave-from
5. 动画离开后 .slide-leave-to
6. 动画离开时段 .slide-leave-active 这个时间段指定动画

注意事项：

1. transition 组件大小写都可用
2. transition 一定要包裹最外层的元素，比如说这里如果只拿来包裹 pop-msg-item 就不能用了
3. transition 如果里面有多个组件要动态渲染，比如列表，就是用 transition-group

```html
<transition-group name="slide">
	<view v-for="(item, index) in tempList" :key="index" style="display: block">
		<pop-msg-item :info="item" class="margin-bottom-xs"></pop-msg-item>
	</view>
</transition-group>
```

```scss
.slide-enter-active {
	animation: slidein 0.5s; // 指定进场动画 离场动画
}
.slide-leave-active {
	// 激活状态的效果
	animation: slideout 0.5s;
}
@keyframes slidein {
	from {
		margin-left: -100%;
		width: 300%;
	}
	to {
		margin-left: 0%;
		width: 100%;
	}
}
@keyframes slideout {
	from {
		margin-left: 0%;
		width: 100%;
	}
	to {
		margin-left: -100%;
		width: 300%;
	}
}
```

# 两个类实现池+状态维持的的效果

所谓池就是有消息进出，先进先出的效果。

现在有个需求
我需要维护一个池，这个池里面的信息会定期销毁，并且如果新的信息进来和池里面的信息是同属一个 id 的，就更新里面的内容，并且重置销毁倒计时。
这里就遇到一个问题，这个池里面的信息必须要有自己的计时器，这个池里面的信息必须要能保持状态，才能更新，所以用类来做。

```javascript
export class Temp {
	constructor() {
		this.tempList = []
	}
	addItem(item) {
		const tmpItem = new TempItem(item, this)
		this.tempList.push(tmpItem)
		// console.log('this.tempList', this.tempList)
	}
	removeItem(tmpItem) {
		const index = this.tempList.findIndex((ele) => {
			return ele === tmpItem
		})
		this.tempList[index] = null
		this.tempList.splice(index, 1)
		// console.log('this.tempList', this.tempList)
	}
	resetCountdown(tempItem) {
		const index = this.tempList.findIndex((ele, index) => {
			return ele.id === tempItem.id
		})
		this.tempList[index].countdown = 5
	}
	findItem(item) {
		const index = this.tempList.findIndex((ele, index) => {
			return ele.id === item.id
		})
		if (index === -1) {
			return null
		} else {
			return this.tempList[index]
		}
	}
	dealItem(item) {
		// 核心步骤，管理tempItem
		const index = this.tempList.findIndex((ele, index) => {
			// console.log('ele')
			return ele.id === item.id
		})
		/* 先查找暂存数组里面有没有这个item */
		if (index === -1) {
			/* 没有就添加item */
			this.addItem(item)
		} else {
			/* 有的话获取到tempItem和新item比对 */
			console.log('giftId', this.tempList[index].giftId, item.giftId)
			if (this.tempList[index].giftId === item.giftId) {
				this.tempList[index].addGiftNum(item.giftInfo.giftNum)
			} else {
				this.tempList[index].changeGift(item)
			}
		}
	}
}
export class TempItem {
	constructor(item, myTemp) {
		this.item = item
		this.countdown = 5
		var timer = setInterval(() => {
			if (this.countdown === 0) {
				this.destory()
				clearInterval(timer)
			}
			this.down()
		}, 1000)
		this.myTemp = myTemp
	}
	down() {
		this.countdown -= 1
		// console.log('down', this.countdown, this.item)
	}
	reset() {
		this.countdown = 5
		// console.log('reset', this.countdown)
	}
	get id() {
		return this.item.id
	}
	get giftId() {
		return this.item.giftId
	}
	addGiftNum(giftNum) {
		this.item.giftInfo.giftNum += giftNum
		this.reset()
	}
	changeGift(item) {
		this.item = JSON.parse(JSON.stringify(item))
		this.reset()
	}
	destory() {
		this.myTemp.removeItem(this) // 核心步骤，调用池的方法来销毁自己
	}
}
```

# socket 信息重复发送问题

socket 建立链接，只是第一步，
第二步是，你要和后端交换信息，验证你通过了(第二次链接 conn),后端才会给你发送数据。

调用 this.ws.disconnect() 关闭的是第一步的链接
这里我们没有定义第二步链接的关闭方法。

他可能在第二步链接的时候，链接了其他的接口获取了其他数据

# 重命名的意义

重命名可能就可以直接复制结构过去，然后重新命名一下就行了。不然手动修改还挺麻烦。

例如下面，其实两个结构是一样的， 只不过是部分变量名字改变了一下

```HTML
					<u-th class="u-th" width="10%">Total</u-th>
					<u-th class="u-th" width="9%">{{ pointObj.away.total.total }}</u-th>
					<u-th class="u-th" width="9%">{{ pointObj.away.total.win }}</u-th>
					<u-th class="u-th" width="9%">{{ pointObj.away.total.draw }}</u-th>
					<u-th class="u-th" width="9%">{{ pointObj.away.total.lose }}</u-th>
					<u-th class="u-th" width="9%">{{ pointObj.away.total.score }}</u-th>
					<u-th class="u-th" width="12%">{{
						pointObj.away.total.goals_against
					}}</u-th>

					<u-tr class="u-tr">
						<u-th class="u-th" width="10%">Away</u-th>
						<u-th class="u-th" width="9%">{{ pointObj.home.away.total }}</u-th>
						<u-th class="u-th" width="9%">{{ pointObj.home.away.win }}</u-th>
						<u-th class="u-th" width="9%">{{ pointObj.home.away.draw }}</u-th>
						<u-th class="u-th" width="9%">{{ pointObj.home.away.lose }}</u-th>
						<u-th class="u-th" width=
```

# 路由选择

<component :is></component>
和 router 方式选择的话，router 还是优先的。动态渲染的页面也可以用 routerView 来做。
