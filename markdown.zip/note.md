# Vue 数组的响应式问题

```javascript
			open(index, outerIndex, list) {
				console.log('open', index, list[index])
				// 先将正在被操作的swipeAction标记为打开状态，否则由于props的特性限制，
				// 原本为'false'，再次设置为'false'会无效
				this.handleData(list)
				list[outerIndex].list[index].show = true
				console.log('this.', this.newsList)
				this.newsList = JSON.parse(JSON.stringify(list))
			},
```

- Vue 会根据 diff 算法来比较虚拟 DOM 进行识图的更新，所以 key 不变的 虚拟 DOM 是不会进行视图上的更新的。
- 所以仅仅是改变数组里面的某一个对象的某一个属性，这个数组不会改变。这个时候可以先对数组进行修改。
- 修改完成以后，如果直接把数组赋值给原数组是没有用的。因为本来就是传递的索引，在元素组上进行了修改，这种赋值操作没有任何意义。
- 正确的做法是使用 this.$set 来进行修改。
- 如果是复杂数组，多层嵌套的，可以使用深拷贝，然后把拷贝的结果赋值给源数组。javascript 里面的 deepCopy 用 JSON.parse(JSON.stringify(arr))就可以完成。

# u-swiper-action 的应用

如图所示：左滑删除有封装好的组件，这里用的是 uView 的组件
![u-swiper-action](/markdown/img/u-swiper-action-exmple.jpg)

```html
<u-swipe-action
	:show="item.show"
	:index="index"
	@click="click(index, time.list)" // 右拉菜单触发click方法
	@open="open(index, idx, newsList)" // open方法处理菜单的打开唯一性
	:options="options"
	v-for="(item, index) in time.list"
	:key="index"
>
	<view class="flex">
		<image
			:src="item.mediaw.thumb"
			mode="aspectFill"
			class="br-8"
			style="width: 180rpx; height: 100rpx"
		/>
		<view class="margin-left-xs flex flex-direction justify-between"
			><text class="f-hide w-500 fs-20">{{ item.mediaw.title }}</text
			><text class="fc-b-9 fs-20"
				>{{ item.mediaw.addtime | formatGiven('yyyy-MM-dd hh:ss') }}</text
			></view
		>
	</view>
</u-swipe-action>
```

# 自定义参数覆盖原生参数的问题

```html
<u-swipe-action
	:show="item.show"
	:index="index"
	@click="click"
	@open="open(index, idx, newsList)"
	:options="options"
	v-for="(item, index) in time.list"
	:key="index"
></u-swipe-action>
```

u-swiper-action 这个组件封装好了 click 方法。这种时候如果我们把参数写成 click(list) 想要传递自己的参数进去，就会覆盖掉他的参数

可以通过项目查询，找到这个组件封好的原生组件，然后查看他传参的方式。
把这个组件取出来，变成自己定义的方法。之前那个 tab,tabNav,tabPane。也是通过这种找到原生组件再自定义的方法来搞定的。

注意不要影响到全局的组件，不要同名。

- 突然发现也可以用函数调用的形式传递参数进去

```javascript
@on-list-change="
  (args) => {
    onChoose(item, args)
  }
"
```

# vant 开发和 uniapp 开发

vant 只是适配 H5，默认是适配 px 作为像素。uniapp 是面向所有端的，他的开发需要花经理去调试各个端的兼容性。已经有原生安卓和 IOS 的情况下，vant 开发 H5 会更加高效。

# 直接使用 callback 来操作 原来的数组

```javascript
click(index, index1, list, type) {
  let mediaid = list[index].mediaid
  this.delMyCollection(list[index].mediaid, type, () => {
    list.splice(index, 1)
    this.$u.toast(`deleted`)
  })
},
      /* 删除我的收藏 */
delMyCollection(mediaid, type, callback) {
  delMyCollection(this.uid, this.token, mediaid, type)
    .then((res) => {
      callback()
    })
    .catch((err) => {
      // this.$message.error('3')
    })
},
```

删除操作成功以后，要进行对应的操作，直接使用 callback，简洁清晰方便。
